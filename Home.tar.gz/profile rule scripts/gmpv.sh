#!/bin/bash

export LC_NUMERIC=C 