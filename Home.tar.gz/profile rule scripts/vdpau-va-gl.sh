#!/bin/sh

VDPAU_DRIVER=va_gl
export VDPAU_DRIVER=va_gl
