#!/bin/bash

# Script to set XDG_MENU_PREFIX since it is not being set
export XDG_MENU_PREFIX=cinnamon-

