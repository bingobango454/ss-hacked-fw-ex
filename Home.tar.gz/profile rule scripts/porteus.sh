export DISTRO=porteus
export BOOTDEV=/mnt/sda
export BASEDIR=/mnt/sda
export PORTDIR=/mnt/sda/porteus
export MODDIR=/mnt/sda/porteus/modules
export PORTCFG=/mnt/sda/porteus/porteus-v5.0-x86_64.cfg
